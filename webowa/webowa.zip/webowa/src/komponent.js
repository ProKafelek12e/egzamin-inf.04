import { useState } from "react"

export default function Komponent(){
    const [adres,setAdres] = useState("")
    const [login,setLogin] = useState("")
    const [autoGeneratePassword, setAutoGeneratePassword] = useState(true)
    const [password,setPassword] = useState("")
    const [data, setData] = useState({
        'adres':undefined,
        'login':undefined,
        'password':undefined
    })
    // ***************************
    // nazwa funkcji: saveData
    // opis funkcji: zapisuje dane do stanu z którego odczytuje drugi blok
    // parametry: brak
    // wartość zwracana: brak
    // autor: 00000000000
    const saveData = ()=>{
        setData(
            {
                'adres':adres,
                'login':login,
                'password':password
            }
        )
    }

    return(
        <>
            <div>
                <h1>Menedżer haseł - wykonał 00000000000</h1>
                <div className="form-control d-flex flex-column gap-3 mt-3">
                    <label className="form-label" htmlFor="adres" style={{"textAlign":"left"}}>adres WWW:</label>
                    <input className="form-control" id="adres" placeholder="Adres strony WWW" value={adres} onChange={(e)=>{setAdres(e.target.value)}}/>
                    <label className="form-label" htmlFor="login" style={{"textAlign":"left"}}>Login:</label>
                    <input className="form-control" id="login" placeholder="Twój login" value={login} onChange={(e)=>{setLogin(e.target.value)}}/>
                    <input id="checkbox" type="checkbox" checked={autoGeneratePassword} onChange={(e)=>{setAutoGeneratePassword(!autoGeneratePassword)}} style={{"alignSelf":"baseline"}}/>
                    <label className="form-label" htmlFor="checkbox" style={{"textAlign":"left"}}>Wygeneruj hasło</label>
                    <label className="form-label" htmlFor="password" style={{"textAlign":"left"}}>Hasło:</label>
                    <input className="form-control" id="password" type="password" disabled={autoGeneratePassword} value={password} onChange={(e)=>{setPassword(e.target.value)}}/>
                    <button className="btn btn-primary" onClick={saveData}>Zapisz</button>
                </div>
            </div>
            <div>
                <p style={{"padding":"0.5rem","textAlign":"left"}}>
                    Adres: {data.adres!=undefined && data.adres}
                </p>
                <p style={{"padding":"0.5rem","textAlign":"left"}}>
                    Login: {data.login!=undefined && data.login} 
                </p>
                <p style={{"padding":"0.5rem","textAlign":"left"}}>
                    {data.password==undefined?"Hasło wygenerowane automatycznie":autoGeneratePassword?"Hasło wygenerowane automatycznie":`Hasło: ${data.password}`} 
                </p>    
            </div>
        </>
    )
}