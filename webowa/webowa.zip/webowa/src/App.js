import './App.css';
import Komponent from './komponent';

function App() {
  return (
    <div className="App">
      <Komponent/>
    </div>
  );
}

export default App;
